import java.util.*;
import java.io.IOException;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;




public class Query1 {
	
	ArrayList <Publication> to_be_returned = new ArrayList <Publication>();

	Query1(String autit, String wordOrtit,String year,String rangeYearStart, String rangeYearEnd,boolean sortByYear, boolean sortByRelevance) throws IOException, SAXException
	{
		System.setProperty("jdk.xml.entityExpansionLimit", "0");

		Parser obj = new Parser(autit,wordOrtit,year,rangeYearStart,rangeYearEnd);

		XMLReader p = XMLReaderFactory.createXMLReader();
		p.setContentHandler(obj);
		p.parse("dblp.xml");

		to_be_returned = obj.getPublication();
		if(sortByYear)
			Collections.sort(to_be_returned, new ComparatorByDate());
		// else if(sortByRelevance)
		// 	Collections.sort(to_be_returned, new ComparatorByRelevance());
	}
	
	public ArrayList <Publication> getPublication()
	{
		return to_be_returned;
	}

}