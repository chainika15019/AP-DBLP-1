import java.util.*;

public class ComparatorByDate implements Comparator<Publication>
{
	@Override
	public int compare(Publication obj1, Publication obj2)
	{
		return obj2.getYear() - obj1.getYear();
	}
}