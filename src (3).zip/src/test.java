import java.lang.*;
import java.util.*;

public class test {
	public static void main(String[] args)
	{
		String str = "lund chutad mootad chainika chutiya";
		ArrayList <String> al = new ArrayList <String>();
		String tmp = new String();
		for(int i = 0 ; i < str.length() ; i++)
		{
			if(str.charAt(i) != ' ')
			{
				tmp += str.charAt(i);
			}
			else
			{
				al.add(tmp);
				tmp = new String();
			}
		}
		for(int i = 0 ; i < al.size() ; i++)
		{
			System.out.println(al.get(i));
		}
	}
}