import java.util.*;
import java.io.IOException;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;



public class Query1 {
	
	ArrayList <Publication> to_be_returned;

	Query1(String autit, String wordOrtit,String year,String rangeYearStart, String rangeYearEnd) throws IOException, SAXException
	{
		System.setProperty("jdk.xml.entityExpansionLimit", "0");

		Parser obj = new Parser(autit,wordOrtit,year,rangeYearStart,rangeYearEnd);
		
		XMLReader p = XMLReaderFactory.createXMLReader();
		p.setContentHandler(obj);
		p.parse("dblp.xml");

		to_be_returned = obj.getPublication(); 
		
	}
	
	public ArrayList <Publication> getPublication()
	{
		return to_be_returned;
	}

}